import json

json_payload = {
"RFID":"1C7784",
"Camera": "NONE",
"ReaderID": "36996276-cb00-40a2-a81e-d7f95858ca7c",
"ControllerID": "A840411BE7CB",
"DoorID": 1,
"StatusCode": "",
}

#json_payload["Camera"] = {"e", "d"}

#json_dump = json.dumps(json_payload)


#print(json_dump)
#print(json_payload)
